package dio.acesscontrol;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AcesscontrolApplication {

	public static void main(String[] args) {
		SpringApplication.run(AcesscontrolApplication.class, args);
	}

}
